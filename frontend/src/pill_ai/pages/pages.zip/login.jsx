import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
/*
  MediPocket — 로그인 페이지
  ──────────────────────────
  사용법:
    import LoginPage from './LoginPage';

    <Route path="/login" element={
      <LoginPage
        onLogin={() => navigate('/app/home')}
        onSignup={() => navigate('/signup')}
      />
    } />
*/

function useCursor() {
  const [cursor, setCursor] = useState({ x: -200, y: -200 });
  const [ring,   setRing  ] = useState({ x: -200, y: -200 });
  const ringPos = useRef({ x: -200, y: -200 });
  const raf     = useRef(null);

  useEffect(() => {
    const onMove = (e) => setCursor({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  useEffect(() => {
    const tick = () => {
      ringPos.current.x += (cursor.x - ringPos.current.x) * 0.14;
      ringPos.current.y += (cursor.y - ringPos.current.y) * 0.14;
      setRing({ x: ringPos.current.x, y: ringPos.current.y });
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [cursor]);

  return { cursor, ring };
}

function Chk({ checked, onChange }) {
  return (
    <div className={`au-chk${checked ? " on" : ""}`} onClick={onChange}>
      {checked && <span className="au-chk-mark">✓</span>}
    </div>
  );
}

function SocBtn({ bg, color, border, shadow, icon, iconStyle, label }) {
  return (
    <button
      className="au-soc"
      style={{
        background: bg,
        color,
        border: border ? `1.5px solid ${border}` : "1.5px solid transparent",
        boxShadow: `0 4px 12px ${shadow}`,
      }}
    >
      <span className="au-soc-icon" style={iconStyle}>{icon}</span>
      {label}
    </button>
  );
}

export default function LoginPage({ onLogin, onSignup }) {
  const navigate = useNavigate();
  const { cursor, ring } = useCursor();
  const [id,     setId    ] = useState("");
  const [pw,     setPw    ] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [saveId, setSaveId] = useState(false);
  const [idF,    setIdF   ] = useState(false);
  const [pwF,    setPwF   ] = useState(false);

  return (
    <>
      <style>{CSS}</style>
      <div className="au-cursor"      style={{ left: cursor.x, top: cursor.y }} />
      <div className="au-cursor-ring" style={{ left: ring.x,   top: ring.y   }} />

      <div className="au-bg-blob" />
      <div className="au-deco au-d1">💊</div>
      <div className="au-deco au-d2">⏰</div>
      <div className="au-deco au-d3">⭐</div>
      <div className="au-deco au-d4">💜</div>

      {/* NAV */}
      <nav className="au-nav">
        <div className="au-nav-logo">
          <div className="au-logo-pill">💊</div>
          <span className="au-logo-text">MediPocket</span>
        </div>
        <div className="au-nav-links">
          <button>서비스소개</button>
          <button>기능</button>
          <button>사용법</button>
        </div>
        <div className="au-nav-r">
          <button className="au-btn-ghost"  onClick={onLogin}>로그인</button>
          <button className="au-btn-pri-sm" onClick={onSignup}>무료로 시작</button>
        </div>
      </nav>

      {/* 카드 */}
      <div className="au-page-wrap">
        <div className="au-card au-login-card">

          <div className="au-card-logo">
            <div className="au-card-logo-icon">💊</div>
            <span className="au-card-logo-text">MediPocket</span>
          </div>

          <div className="au-card-title">로그인</div>
          <div className="au-card-sub">안전한 복약 관리를 위해 로그인하세요.</div>

          <div className="au-field">
            <div className="au-lbl">아이디 또는 이메일</div>
            <div className={`au-inp-wrap${idF ? " focus" : ""}`}>
              <input type="text" placeholder="아이디 또는 이메일"
                value={id} onChange={e => setId(e.target.value)}
                onFocus={() => setIdF(true)} onBlur={() => setIdF(false)} />
            </div>
          </div>

          <div className="au-field">
            <div className="au-lbl">비밀번호</div>
            <div className={`au-inp-wrap${pwF ? " focus" : ""}`}>
              <input type={showPw ? "text" : "password"} placeholder="비밀번호"
                value={pw} onChange={e => setPw(e.target.value)}
                onFocus={() => setPwF(true)} onBlur={() => setPwF(false)} />
              <button className="au-eye" onClick={() => setShowPw(!showPw)} tabIndex={-1}>
                {showPw ? "🙈" : "👁"}
              </button>
            </div>
          </div>

          <div className="au-opt-row">
            <div className="au-chk-row" onClick={() => setSaveId(!saveId)}>
              <Chk checked={saveId} onChange={() => setSaveId(!saveId)} />
              <span className="au-chk-lbl">아이디 저장</span>
            </div>
            <button className="au-link">비밀번호 찾기</button>
          </div>

          <button className="au-btn-main" onClick={onLogin}>로그인</button>

          <div className="au-div-row">
            <div className="au-div-line" />
            <span className="au-div-txt">또는</span>
            <div className="au-div-line" />
          </div>

          <div className="au-socials">
            <SocBtn bg="#fee500" color="#3a1d1d" shadow="rgba(254,229,0,.3)"
              icon="💬" label="Kakao" />
            <SocBtn bg="#03c75a" color="#fff" shadow="rgba(3,199,90,.25)"
              icon="N" label="NAVER"
              iconStyle={{ fontFamily:"serif", fontWeight:900, fontSize:13 }} />
            <SocBtn bg="#fff" color="#444" shadow="rgba(0,0,0,.06)"
              icon="G" label="Google" border="rgba(0,0,0,.12)"
              iconStyle={{ color:"#4285f4", fontWeight:700, fontSize:13 }} />
          </div>

          <div className="au-foot">
            <span className="au-foot-txt">아직 회원이 아니신가요?</span>
            <button className="au-foot-link" onClick={() => navigate('/app/signup')}>회원가입</button>
          </div>

        </div>
      </div>
    </>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;}
:root{
  --p:#7c3aed;--pl:#ede9fe;--a1:#a78bfa;--a2:#f9a8d4;
  --txt:#1a1433;--sub:#6b7280;--bg:#eeeeff;
  --fn:'Plus Jakarta Sans',sans-serif;
}
html,body{width:100%;min-height:100vh;cursor:none;font-family:var(--fn);background:var(--bg);}

.au-cursor{width:10px;height:10px;border-radius:50%;background:var(--a1);position:fixed;z-index:9999;pointer-events:none;transform:translate(-50%,-50%);mix-blend-mode:multiply;}
.au-cursor-ring{width:32px;height:32px;border-radius:50%;border:1px solid var(--a1);position:fixed;z-index:9998;pointer-events:none;transform:translate(-50%,-50%);opacity:.4;}

.au-bg-blob{position:fixed;inset:0;pointer-events:none;z-index:0;}
.au-bg-blob::before{content:'';position:absolute;width:600px;height:600px;top:-160px;left:-160px;background:radial-gradient(circle,rgba(167,139,250,.22),transparent 65%);animation:auD1 13s ease-in-out infinite alternate;}
.au-bg-blob::after{content:'';position:absolute;width:500px;height:500px;bottom:-100px;right:-80px;background:radial-gradient(circle,rgba(249,168,212,.22),transparent 65%);animation:auD2 16s ease-in-out infinite alternate;}
@keyframes auD1{to{transform:translate(60px,50px)}}
@keyframes auD2{to{transform:translate(-50px,35px)}}

.au-deco{position:fixed;font-size:36px;opacity:.13;pointer-events:none;z-index:1;animation:auDc 7s ease-in-out infinite alternate;}
.au-d1{top:18%;left:5%;animation-delay:0s;}
.au-d2{top:15%;right:4%;animation-delay:1.8s;}
.au-d3{bottom:22%;left:4%;animation-delay:3.2s;}
.au-d4{bottom:20%;right:5%;animation-delay:4.6s;}
@keyframes auDc{from{transform:translateY(0) rotate(-6deg)}to{transform:translateY(-14px) rotate(6deg)}}

.au-nav{position:fixed;top:0;left:0;right:0;z-index:200;height:64px;padding:0 80px;display:flex;justify-content:space-between;align-items:center;background:rgba(240,238,255,.94);backdrop-filter:blur(18px);border-bottom:1px solid rgba(167,139,250,.2);}
.au-nav-logo{display:flex;align-items:center;gap:9px;}
.au-logo-pill{width:34px;height:34px;background:linear-gradient(135deg,var(--a1),var(--a2));border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:17px;box-shadow:0 4px 12px rgba(167,139,250,.4);animation:auPulse 3s ease-in-out infinite;}
@keyframes auPulse{0%,100%{box-shadow:0 4px 12px rgba(167,139,250,.4)}50%{box-shadow:0 4px 20px rgba(167,139,250,.62)}}
.au-logo-text{font-size:17px;font-weight:800;color:var(--txt);}
.au-nav-links{display:flex;gap:2px;}
.au-nav-links button{padding:7px 14px;border-radius:50px;border:none;background:transparent;font-family:var(--fn);font-size:13px;font-weight:600;color:var(--sub);cursor:none;transition:all .2s;}
.au-nav-links button:hover{background:var(--pl);color:var(--p);}
.au-nav-r{display:flex;gap:8px;align-items:center;}
.au-btn-ghost{padding:8px 16px;border-radius:50px;background:transparent;border:1.5px solid rgba(124,58,237,.3);color:var(--p);font-size:13px;font-weight:600;cursor:none;transition:all .2s;font-family:var(--fn);}
.au-btn-ghost:hover{background:var(--pl);}
.au-btn-pri-sm{padding:8px 16px;border-radius:50px;background:linear-gradient(135deg,var(--a1),#818cf8);border:none;color:#fff;font-size:13px;font-weight:600;cursor:none;font-family:var(--fn);transition:all .2s;}
.au-btn-pri-sm:hover{transform:translateY(-1px);}
.au-btn-pri-sm:active{transform:scale(.97);}

.au-page-wrap{position:relative;z-index:10;min-height:calc(100vh - 64px);margin-top:64px;display:flex;align-items:center;justify-content:center;padding:24px 16px 44px;}
.au-card{background:rgba(255,255,255,.96);border:1px solid rgba(255,255,255,.8);border-radius:24px;box-shadow:0 24px 64px rgba(100,60,200,.14);animation:auUp .45s ease both;}
@keyframes auUp{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:translateY(0)}}
.au-login-card{width:460px;padding:40px 46px 36px;}

.au-card-logo{display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:22px;}
.au-card-logo-icon{width:46px;height:46px;background:linear-gradient(135deg,#f97316,var(--a2));border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;box-shadow:0 6px 18px rgba(249,115,22,.28);}
.au-card-logo-text{font-size:21px;font-weight:800;color:var(--txt);}
.au-card-title{font-size:30px;font-weight:800;color:var(--txt);text-align:center;letter-spacing:.05em;margin-bottom:5px;}
.au-card-sub{font-size:13px;color:var(--sub);text-align:center;margin-bottom:22px;line-height:1.6;}

.au-field{display:flex;flex-direction:column;gap:5px;margin-bottom:12px;}
.au-lbl{font-size:12px;font-weight:600;color:var(--txt);}
.au-inp-wrap{display:flex;align-items:center;background:#f8f7ff;border:1.5px solid rgba(167,139,250,.22);border-radius:11px;overflow:hidden;transition:border-color .2s,box-shadow .2s;}
.au-inp-wrap.focus{border-color:var(--a1);box-shadow:0 0 0 3px rgba(167,139,250,.13);}
.au-inp-wrap input{flex:1;border:none;background:transparent;font-family:var(--fn);font-size:13px;color:var(--txt);outline:none;padding:11px 13px;cursor:text;}
.au-inp-wrap input::placeholder{color:#a0aec0;}
.au-eye{background:transparent;border:none;cursor:none;padding:0 11px;font-size:15px;color:#b8a8d8;transition:color .2s;line-height:1;}
.au-eye:hover{color:var(--p);}

.au-opt-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:13px;}
.au-chk-row{display:flex;align-items:center;gap:6px;cursor:none;user-select:none;}
.au-chk{width:16px;height:16px;border:1.5px solid #ccc;border-radius:4px;display:flex;align-items:center;justify-content:center;transition:all .2s;flex-shrink:0;}
.au-chk.on{background:var(--p);border-color:var(--p);}
.au-chk-mark{color:#fff;font-size:9px;font-weight:700;}
.au-chk-lbl{font-size:12px;color:var(--sub);}
.au-link{background:transparent;border:none;font-family:var(--fn);font-size:12px;font-weight:600;color:var(--p);cursor:none;}
.au-link:hover{text-decoration:underline;}

.au-btn-main{width:100%;padding:13px;border-radius:50px;background:linear-gradient(135deg,var(--p),#818cf8);border:none;color:#fff;font-size:14px;font-weight:700;cursor:none;font-family:var(--fn);box-shadow:0 6px 22px rgba(124,58,237,.35);transition:transform .2s,box-shadow .2s;margin-bottom:16px;}
.au-btn-main:hover{transform:translateY(-2px);box-shadow:0 10px 28px rgba(124,58,237,.48);}
.au-btn-main:active{transform:scale(.97);}

.au-div-row{display:flex;align-items:center;gap:8px;margin-bottom:14px;}
.au-div-line{flex:1;height:1px;background:rgba(167,139,250,.2);}
.au-div-txt{font-size:11px;color:#b8a8d8;font-weight:500;white-space:nowrap;}

.au-socials{display:flex;gap:8px;margin-bottom:18px;}
.au-soc{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;border-radius:50px;padding:10px 8px;font-family:var(--fn);font-size:12px;font-weight:600;cursor:none;transition:transform .2s;}
.au-soc:hover{transform:translateY(-2px);}
.au-soc:active{transform:scale(.97);}
.au-soc-icon{font-size:14px;display:flex;align-items:center;justify-content:center;width:16px;height:16px;}

.au-foot{display:flex;justify-content:center;align-items:center;gap:5px;}
.au-foot-txt{font-size:12px;color:var(--sub);}
.au-foot-link{background:transparent;border:none;font-family:var(--fn);font-size:12px;font-weight:700;color:var(--p);cursor:none;}
.au-foot-link:hover{text-decoration:underline;}
`;
